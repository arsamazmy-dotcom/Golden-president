# ساخت APK فقط با گوشی

این پروژه برای GitHub Actions آماده شده است؛ بنابراین برای Build نیازی به Android Studio یا لپ‌تاپ نیست. GitHub Actions می‌تواند workflow را روی سرور خودش اجرا کند و فایل APK را به‌صورت artifact تحویل دهد.

## مراحل

1. در گوشی وارد GitHub شوید و یک حساب بسازید.
2. یک Repository جدید بسازید؛ ترجیحاً Private.
3. تمام فایل‌های این پروژه را داخل Repository آپلود کنید. فایل `.github/workflows/build-apk.yml` هم حتماً باید حفظ شود.
4. وارد تب **Actions** شوید.
5. Workflow با نام **Build Android APK** را انتخاب کنید.
6. گزینه **Run workflow** را بزنید.
7. بعد از سبز شدن Build، وارد همان اجرای موفق شوید.
8. در پایین صفحه بخش **Artifacts**، فایل `golden-president-debug-apk` را دانلود کنید.
9. ZIP مربوط به artifact را روی گوشی باز کنید و APK را نصب کنید.

## نکته مهم درباره نسخه انتشار

این workflow فعلاً APK تستی (Debug) می‌سازد. برای انتشار واقعی در مایکت باید Release APK/AAB با کلید امضای دائمی خودتان ساخته شود. کلید امضا را هرگز داخل Repository عمومی قرار ندهید؛ برای آن باید GitHub Secrets تنظیم شود.
