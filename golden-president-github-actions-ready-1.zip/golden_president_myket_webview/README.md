# Golden President — Android WebView + Myket Billing + Ads

This project wraps the current HTML game in an Android WebView.

## Payment
- Myket Billing Client: `com.github.myketstore:myket-billing-client:1.19`
- Public RSA key supplied for this game is placed in `BuildConfig.MYKET_PUBLIC_KEY`.
- HTML calls `MyketBridge.purchase(id)` and `MyketBridge.restore()`.
- Consumable IDs: `gp_capital_50k`, `gp_capital_180k`, `gp_capital_400k`.
- Non-consumable IDs: `gp_premium`, `gp_no_ads`.

## Ads
Myket's public Android repository used here is the billing SDK; it does not document a public Myket ad SDK. Therefore the ad bridge uses Yandex Mobile Ads 8.2.0 for rewarded/interstitial ads. Yandex documents rewarded and interstitial formats for Android and requires an ad-unit ID from its advertising dashboard.

Replace these two BuildConfig values in `app/build.gradle` with your production IDs:
- `INTERSTITIAL_AD_UNIT_ID`
- `REWARDED_AD_UNIT_ID`

The current values are placeholders for configuration and are not production IDs.

## HTML bridge
The HTML already calls:
- `MyketBridge.purchase(productId)`
- `MyketBridge.restore()`
- `MyketBridge.showRewarded()`
- `MyketBridge.showInterstitial()`

Android calls back:
- `window.onMyketPurchaseSuccess(id)`
- `window.onMyketPurchaseFailed(message)`
- `window.onMyketPurchaseRestored(id)`
- `window.onMyketRewardedCompleted()`
- `window.onMyketRewardedFailed()`

## Build
Open the project in Android Studio (AGP 8.7+), sync Gradle, then build APK/AAB.

Before publishing, create the exact product IDs in the Myket developer panel and replace the ad unit IDs with your own production IDs.
